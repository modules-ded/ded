@echo

python bot.py
en
Jhon
14767080
c23d8b60b7c12dedb04052bafc90cb08
python 