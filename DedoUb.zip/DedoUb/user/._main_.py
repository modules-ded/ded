import os

os.system('python bot.py')