import os
import subprocess
import colorama
from colorama import Fore, Style

try:
    import telethon
except ImportError:
    print(Fore.GREEN + "🚫 Not modules")
    print(Fore.RED + "ℹ Installing python modules")
    subprocess.call(['pkg', 'i', 'git',  'python', 'libjpeg-turbo', 'openssl', '-y'], stdout=subprocess.DEVNULL)
    subprocess.call(['pkg', 'install', 'python'], stdout=subprocess.DEVNULL)
    subprocess.call(['pip', 'install', 'telethon'], stdout=subprocess.DEVNULL)
    print(Fore.RED + "ℹ Installing successful")

os.system('python start.py')