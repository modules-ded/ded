#!/bin/bash

printf "\n\n\033[1;35mDed user-bot устанавливается... ✨\033[0m"

echo -e "\n\n\033[0;96mУстановка пакетов...\033[0m"

eval "pkg i git python libjpeg-turbo openssl -y"

printf "\r\033[K\033[0;32mПакеты установлены!\e[0m\n"

echo -e "\033[0;96mStarting User-Bot...\033[0m"

printf "\033[1;32mUser-Bot is starting...\033[0m\n"

eval "python3 -m hikka"
