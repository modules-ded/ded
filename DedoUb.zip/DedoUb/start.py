import os

os.system("cd user")
os.system("python bot.py")