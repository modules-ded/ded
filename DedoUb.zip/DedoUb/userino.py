import asyncio
import re
import aiogram
from aiogram import Bot, types, executor, Dispatcher    
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
from aiogram.utils.markdown import hlink
import sqlite3 as sq
import random
import datetime
from datetime import timedelta, datetime
import time
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import asyncio
import aiohttp
import time
from datetime import datetime

TOKEN = "6327643797:AAF5gwaRD2OABRPA9KVKDDsH7noUncNhrmw"

bot = Bot(token=TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

@dp.message_handler(content_types=['text'])
async def handle_menu_buttons(message):
    low = message.text.lower()
    if low == "тест":
        await message.answer("ку")
        
if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)